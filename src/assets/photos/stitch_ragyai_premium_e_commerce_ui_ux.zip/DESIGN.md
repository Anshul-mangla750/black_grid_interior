---
name: Ragyai Visual Identity
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#444748'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#6b38d4'
  on-secondary: '#ffffff'
  secondary-container: '#8455ef'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#261900'
  on-tertiary-container: '#9f7f40'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474746'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffdea3'
  tertiary-fixed-dim: '#e6c27c'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5b4307'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-md:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  section: 80px
  gutter: 24px
  margin-mobile: 20px
  margin-desktop: 64px
---

## Brand & Style
The design system embodies a "Contemporary Indian Editorial" aesthetic. It balances the warmth of traditional Indian craft with the precision of modern minimalism. The visual narrative is built on the concept of "The Canvas and the Ink"—where the background is a warm, tactile surface and the typography is sharp and intentional.

The style leans heavily into **Minimalism** with an **Artistic** editorial edge. It prioritizes vast whitespace (breathing room), thin hairlines for structure, and a sophisticated interplay between high-contrast serif headings and functional sans-serif UI elements. The emotional response is one of calm, premium quality, and cultural pride.

## Colors
The palette is rooted in an "off-white" warmth to avoid the clinical feel of pure white.
- **Base:** The primary background (#FAF8F3) mimics high-quality paper or unbleached cotton.
- **Accents:** The Purple Accent provides a contemporary fashion edge, used sparingly for calls to action or seasonal highlights. The Gold Accent is reserved for premium touches, "Limited Edition" tags, or heritage storytelling.
- **Typography:** Deep charcoal (#171717) is used instead of pure black to maintain softness against the beige background.

## Typography
Typography is the core of this design system's editorial feel. 
- **Headlines:** Use Playfair Display with tighter letter-spacing for large displays. It should feel authoritative yet graceful.
- **Body & UI:** Manrope provides a modern, slightly wider stance that aids readability on digital screens while feeling more "designed" than a standard neo-grotesque. 
- **Labels:** Small caps and increased letter-spacing should be used for categories, breadcrumbs, and eyebrow text to create a rhythmic hierarchy.

## Layout & Spacing
The layout follows a **Fluid Grid** model with an emphasis on asymmetric arrangements to mimic fashion magazine spreads. 
- **Desktop:** 12-column grid with wide 64px outer margins to "frame" the content.
- **Mobile:** 4-column grid with 20px margins.
- **Rhythm:** Use large vertical gaps (section-level spacing) to separate different product stories. Content should not feel crowded; if in doubt, increase the whitespace. 
- **Asymmetry:** Occasionally offset images or text blocks by 1-2 columns to create visual interest and an "artistic" flow.

## Elevation & Depth
This design system avoids heavy drop shadows, opting instead for **Tonal Layers** and **Low-Contrast Outlines**.
- **Surfaces:** Depth is created by placing #FFFFFF (White) surfaces on top of #FAF8F3 (Paper) backgrounds.
- **Borders:** Use 1px solid lines in #E5E0D8 to define sections and cards. This creates a "blueprint" or "gallery" feel.
- **Glassmorphism:** The sticky navbar uses a heavy backdrop blur (20px) with a semi-transparent #FAF8F3 (80% opacity) and a thin bottom border to maintain the editorial structure during scroll.
- **Interaction:** On hover, a very subtle, diffused ambient shadow (color: #171717, alpha: 0.04, blur: 12px) may be used to indicate lift.

## Shapes
The shape language is **Soft**. 
- Primary buttons and containers use a subtle 0.25rem (4px) radius. This provides just enough softness to feel contemporary without losing the architectural strength of a rectangular grid. 
- Product imagery should maintain sharp 0px corners to emphasize the "Editorial Photography" look, while UI elements like input fields and tags take the soft rounding.

## Components
- **Buttons:** 
  - *Primary:* Solid #171717 background with #FAF8F3 text. Sharp or 4px rounded. 
  - *Secondary:* Ghost style with 1px #171717 border.
- **Product Cards:** No shadows. A 1px border (#E5E0D8) frames the image. Typography is left-aligned, using `headline-sm` for titles and `body-md` for pricing.
- **Chips/Tags:** Use the #F1ECE3 background with `label-sm` text. For "New Arrivals," use a Soft Lavender (#EDE4FF) background with Purple text.
- **Input Fields:** Bottom-border only (1px #E5E0D8) for a minimalist "form" feel, or a fully enclosed box with 4px rounding and no background fill.
- **Icons:** Use ultra-thin (1px or 1.5px stroke) line icons. Avoid filled icons unless used for active states.
- **Sticky Navbar:** Positioned at the top, utilizes `backdrop-filter: blur(10px)` and a 1px bottom border. Brand logo centered for the editorial look.